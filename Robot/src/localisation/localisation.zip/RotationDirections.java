package localisation;

public class RotationDirections {
	static final int LEFT=0;
	static final int RIGHT=1;
	static final int FORWARD=2;
}
